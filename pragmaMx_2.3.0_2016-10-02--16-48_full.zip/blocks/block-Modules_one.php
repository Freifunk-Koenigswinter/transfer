<?php
/**
 * This file is part of
 * pragmaMx - Web Content Management System.
 * Copyright by pragmaMx Developer Team - http://www.pragmamx.org
 *
 * pragmaMx is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * $Revision: 6 $
 * $Author: PragmaMx $
 * $Date: 2015-07-08 09:07:06 +0200 (Mi, 08. Jul 2015) $
 */

if (!defined("mxMainFileLoaded")) die ("You can't access this file directly...");

/* --------- Konfiguration fuer den Block ----------------------------------- */

/**
 * link to homepage (alternate: index.php )
 */
$homelink = './';

/**
 * image path relative to public root
 */
$image_normal = "images/menu/rarrow.gif";

/**
 * image path relative to public root
 */
$image_current = "images/menu/oarrow.gif";

/**
 * max. Number of charakters in Moduleslist
 */
$maxwordlen = 20;

/**
 * Heigth of the scrolling Layer for Moduleslist
 */
$listheigth['normal'] = 0;

/**
 * Design im alten pragmaMx.org Stil anzeigen?  Wird evtl. von
 * der entsprechenden Themeeinstellung ($themePmxStyle) ueberschrieben!!
 */
$pmxStyle = false;

/**
 * Breite der Tabelle im alten pragmaMx.org Stil.  Wird evtl. von
 * der entsprechenden Themeeinstellung ($themePmxStyleWidth) ueberschrieben!!
 */
$pmxStyleWidth = '146px';

/* --------- Ende der Konfiguration ----------------------------------------- */

extract($block['settings'], EXTR_OVERWRITE);

global $prefix, $themePmxStyle, $themePmxStyleWidth, $themesetting;

/* allow to cache this Block */
$mxblockcache = false;

switch (true) {
    case isset($themesetting['blocknav']):
        /* neue Themes ab 0.1.10 sp1, koennen die beiden Einstellungen mitbringen */
        $style = 'modern';
        $class_ul = (isset($themesetting['blocknav']['style'])) ? $themesetting['blocknav']['style']: 'leftmenu';
        $class_li = (isset($themesetting['blocknav']['current'])) ? $themesetting['blocknav']['current']: 'current';
        $image_normal = '';
        $image_current = ' class="' . $class_li . '"';
        $menuline = '<li%s%s><a href="%s">%s</a></li>';
        break;
    case isset($themePmxStyle, $themePmxStyleWidth):
        /* neuere Themes fuer 0.1.9 koennen diese beiden Einstellungen mitbringen  */
        $pmxStyle = $themePmxStyle;
        $pmxStyleWidth = $themePmxStyleWidth;
    case $pmxStyle:
        /* oder eben direkt im Block eingeschaltet */
        $style = 'classic';
        $image_normal = '';
        $image_current = '';
        $menuline = '<tr%s><td class="leftmenu">%s<a href="%s">%s</a></td></tr>';
        break;
    default:
        /* zum Schluss der veraltete Standard-Stil, mit den Bildchen davor */
        $style = 'outdated';
        $image_normal = mxCreateImage($image_normal, '~');
        $image_current = mxCreateImage($image_current, '~');
        $menuline = '<tr%s><td>%s&nbsp;<a href="%s">%s</a></td></tr>';
}

$thismodulblock = preg_replace('#^block-(.+)\.php$#', '\1', basename(__file__));
$main_module = mxGetMainModuleName();

$opti = array();
$result = sql_query("SELECT title, custom_title FROM ${prefix}_modules WHERE active=1 AND main_id='" . $thismodulblock . "'");
while (list($mod_name, $custom_title) = sql_fetch_row($result)) {
    if ($mod_name == $main_module) {
        $sorter = '00';
        $custom_title = _HOME;
        $link = $homelink;
        $img = (defined('MX_HOME_FILE')) ? $image_current : $image_normal;
    } else if (mxModuleAllowed($mod_name)) {
        $custom_title = mxTranslate($custom_title);
        $sorter = strtolower($custom_title);
        $custom_title = (empty($custom_title)) ? str_replace("_", " ", $mod_name) : $custom_title;
        $link = 'modules.php?name=' . urlencode($mod_name);
        $img = ($mod_name === MX_MODULE) ? $image_current : $image_normal;
    } else {
        continue;
    }
    $view_title = mxCutString($custom_title, $maxwordlen, "..", "");
    $titleattribut = ($custom_title === $view_title) ? '' : ' title="' . $custom_title . '"';
    $opti[$sorter] = sprintf($menuline, $titleattribut, $img, $link, $view_title);
}

$content = '';
if ($opti) {
    ksort($opti, SORT_STRING);
    $heigth = ($listheigth['normal']) ? ' style="height: ' . $listheigth['normal'] . 'px; overflow : auto;"' : '';
    switch ($style) {
        case 'modern':
            $content .= '<ul class="' . $class_ul . '"' . $heigth . '>' . implode("\n", $opti) . '</ul>';
            break;
        case 'classic':
            $content .= '<div' . $heigth . '><table align="center" cellpadding="1" cellspacing="0" style="width:' . $pmxStyleWidth . ';">';
            $content .= str_replace('alt="~" title="~"', 'alt=""', implode("\n", $opti));
            $content .= '</table></div>';
            break;
        case 'outdated':
        default:
            $content .= '<div' . $heigth . '><table cellpadding="1" cellspacing="0" width="100%">';
            $content .= str_replace('alt="~" title="~"', 'alt=""', implode("\n", $opti));
            $content .= '</table></div>';
    }
}

?>