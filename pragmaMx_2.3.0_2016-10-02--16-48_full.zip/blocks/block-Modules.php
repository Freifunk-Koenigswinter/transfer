<?php
/**
 * This file is part of
 * pragmaMx - Web Content Management System.
 * Copyright by pragmaMx Developer Team - http://www.pragmamx.org
 *
 * pragmaMx is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * $Revision: 6 $
 * $Author: PragmaMx $
 * $Date: 2015-07-08 09:07:06 +0200 (Mi, 08. Jul 2015) $
 */

if (!defined("mxMainFileLoaded")) die ("You can't access this file directly...");

/* --------- Konfiguration fuer den Block ----------------------------------- */

/**
 * link to homepage (alternate: index.php )
 */
$homelink = './';
/**
 * Show all active modules, or only this where set to this Block
 */
$showallmodules = 0;
/**
 * Show inaktive modules for admin to test it
 */
$showinaktive = 1;
/**
 * Show link to adminmenue
 */
$showadminlink = 1;
/**
 * image path relative to public root
 */
$image_normal = "images/menu/rarrow.gif";

/**
 * image path relative to public root
 */
$image_current = "images/menu/oarrow.gif";

/**
 * image path relative to public root
 */
$image_admin = "images/menu/barrow.gif";
/**
 * max. Number of charakters in Moduleslist
 */
$maxwordlen = 20;

/**
 * Heigth of the scrolling Layer for Moduleslist
 */
$listheigth['normal'] = 0;

/**
 * Heigth of the scrolling Layer for inactive Moduleslist
 */
$listheigth['deaktiv'] = 100;

/**
 * Heigth of the scrolling Layer for hided Moduleslist
 */
$listheigth['hidden'] = 70;

/**
 * Design im alten pragmaMx.org Stil anzeigen?  Wird evtl. von
 * der entsprechenden Themeeinstellung ($themePmxStyle) ueberschrieben!!
 */
$pmxStyle = false;

/**
 * Breite der Tabelle im alten pragmaMx.org Stil.  Wird evtl. von
 * der entsprechenden Themeeinstellung ($themePmxStyleWidth) ueberschrieben!!
 */
$pmxStyleWidth = '146px';

/* --------- Ende der Konfiguration ----------------------------------------- */

extract($block['settings'], EXTR_OVERWRITE);

global $prefix, $themePmxStyle, $themePmxStyleWidth, $themesetting;

/* allow to cache this Block */
$mxblockcache = false;

switch (true) {
    case isset($themesetting['blocknav']):
        /* neue Themes ab 0.1.10 sp1, koennen die beiden Einstellungen mitbringen */
        $style = 'modern';
        $class_ul = (isset($themesetting['blocknav']['style'])) ? $themesetting['blocknav']['style']: 'leftmenu';
        $class_li = (isset($themesetting['blocknav']['current'])) ? $themesetting['blocknav']['current']: 'current';
        $image_normal = '';
        $image_current = ' class="' . $class_li . '"';
        $image_admin = '';
        $menuline = '<li%s%s><a href="%s">%s</a></li>';
        break;
    case isset($themePmxStyle, $themePmxStyleWidth):
        /* neuere Themes fuer 0.1.9 koennen diese beiden Einstellungen mitbringen  */
        $pmxStyle = $themePmxStyle;
        $pmxStyleWidth = $themePmxStyleWidth;
    case $pmxStyle:
        /* oder eben direkt im Block eingeschaltet */
        $style = 'classic';
        $image_normal = '';
        $image_current = '';
        $image_admin = '';
        $menuline = '<tr%s><td class="leftmenu">%s<a href="%s">%s</a></td></tr>';
        break;
    default:
        /* zum Schluss der veraltete Standard-Stil, mit den Bildchen davor */
        $style = 'outdated';
        $image_normal = mxCreateImage($image_normal, '~');
        $image_current = mxCreateImage($image_current, '~');
        $image_admin = mxCreateImage($image_admin, '~');
        $menuline = '<tr%s><td>%s&nbsp;<a href="%s">%s</a></td></tr>';
}

/* Bereiche-Array vorher erstellen, damit die Sortierung passt ;)  */
$opti = array('normal' => array(),
    'deaktiv' => array(),
    'hidden' => array()
    );

/* Die Ueberschriften der einzelnen Bereiche */
$caption = array('normal' => '',
    'deaktiv' => '<div class="tiny box"><b>' . _NOACTIVEMODULES . '</b><br />' . _FORADMINTESTS . '</div>',
    'hidden' => '<div class="tiny box"><b>' . _NOVIEWEDMODULES . '</b><br />' . _FORADMINTESTS . '</div>'
    );

$thismodulblock = preg_replace('#^block-(.+)\.php$#', '\1', basename(__FILE__));
$main_module = mxGetMainModuleName();

$where = (MX_IS_ADMIN && $showinaktive) ? "WHERE title<>'CVS'" : "WHERE title<>'CVS' AND (main_id='" . $thismodulblock . "' OR main_id='') AND active=1";
$result = sql_query("select title, custom_title, active, main_id from ${prefix}_modules $where");
while (list($mod_name, $custom_title, $active, $main_id) = sql_fetch_row($result)) {
    $showit = ($showallmodules || empty($main_id) || ($main_id == $thismodulblock)) ? 1 : 0;
    switch (true) {
        case (MX_IS_ADMIN && $active && $main_id == "hided"):
            $cat = 'hidden';
            break;
        case (MX_IS_ADMIN && !$active):
            $cat = 'deaktiv';
            break;
        case ($active && $showit && (MX_IS_ADMIN || mxModuleAllowed($mod_name))):
            $cat = 'normal';
            break;
        default:
            $cat = '';
            break;
    }
    if ($cat) {
        if ($mod_name == $main_module) {
            $sorter = '00';
            $custom_title = _HOME;
            $link = $homelink;
            $img = (defined('MX_HOME_FILE')) ? $image_current : $image_normal;
        } else {
            $custom_title = mxTranslate($custom_title);
            $sorter = strtolower($custom_title);
            $custom_title = (empty($custom_title)) ? str_replace("_", " ", $mod_name) : $custom_title;
            $link = 'modules.php?name=' . urlencode($mod_name);
            $img = ($mod_name === MX_MODULE) ? $image_current : $image_normal;
        }
        $view_title = mxCutString($custom_title, $maxwordlen, "..", "");
        $titleattribut = ($custom_title === $view_title) ? '' : ' title="' . $custom_title . '"';
        $opti[$cat][$sorter] = sprintf($menuline, $titleattribut, $img, $link, $view_title);
    }
}

if (MX_IS_ADMIN && $showadminlink) {
    $sorter = '01';
    $custom_title = _ADMINMENUEBL;
    $link = adminUrl();
    $img = $image_admin;
    $view_title = mxCutString($custom_title, $maxwordlen, "..", "");
    $titleattribut = ($custom_title === $view_title) ? '' : ' title="' . $custom_title . '"';
    $opti['normal'][$sorter] = sprintf($menuline, $titleattribut, $img, $link, $view_title);
}

$content = '';
foreach ($opti as $type => $entries) {
    if (!$entries) {
        continue;
    }
    ksort($entries, SORT_STRING);
    $heigth = ($listheigth[$type]) ? ' style="max-height: ' . $listheigth[$type] . 'px; overflow : auto;"' : '';
    $content .= $caption[$type];
    switch ($style) {
        case 'modern':
            $content .= '<ul class="' . $class_ul . '"' . $heigth . '>' . implode("\n", $entries) . '</ul>';
            break;
        case 'classic':
            $content .= '<div' . $heigth . '><table align="center" cellpadding="1" cellspacing="0" style="width:' . $pmxStyleWidth . ';">';
            $content .= str_replace('alt="~" title="~"', 'alt=""', implode("\n", $entries));
            $content .= '</table></div>';
            break;
        case 'outdated':
        default:
            $content .= '<div' . $heigth . '><table cellpadding="1" cellspacing="0" width="100%">';
            $content .= str_replace('alt="~" title="~"', 'alt=""', implode("\n", $entries));
            $content .= '</table></div>';
    }
}

?>