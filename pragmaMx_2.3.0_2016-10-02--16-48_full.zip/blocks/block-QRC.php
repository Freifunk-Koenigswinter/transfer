<?php
/**
 *
 * $Revision: 6 $
 * $Author: PragmaMx $
 * $Date: 2015-07-08 09:07:06 +0200 (Mi, 08. Jul 2015) $
 *
 */

defined('mxMainFileLoaded') or die('access denied');

/* --------- Konfiguration fuer den Block ----------------------------------- */

/* 
	erzeugt einen QR-Code aus dem einzugebenden Text
	dieser Service wird kostenlos von http://qrserver.com/ bereitgestellt. 
	Dieser Block nutzt die API von http://qrserver.com/api/
	*/

/* URL 
	standard= Basis-URL der Seite 
	kann beliebig verändert werden.
	z. Bsp. http://www.pragmamx.org
	*/

//$qrcurl="http://www.pragma.mx.org";

$qrcurl=PMX_HOME_URL.$_SERVER['REQUEST_URI'];

/* breite in px */
$qrcsize="150";

/* Titel */
$qrctitle="Link zu dieser Seite";

/* color 
		Gültige Beispiele:
		255-0-0 (rot),
		f00 (rot),
		FF0000 (rot),
		0-255-0 (grün),
		0f0 (grün),
		00ff00 (grün),
		0-0-255 (blau),
		00f (blau),
		0000ff (blau),
		556B2F (DarkOliveGreen)
*/
$qrccolor="000";
$qrcbgcolor="FFF";

/* ecc-Parameter
Speichert den Fehlerkorrektur-Code (Error Correction Code, ECC), welcher den Grad 
der Datenredundanzen bestimmt. Je mehr Datenredundanzen vorliegen, desto mehr Daten 
können bei Beschüdigung des QR-Codes (z.B. Kratzer auf einem QR-Code-Sticker) 
korrigiert werden.
	Mögliche Werte:
	L (low, ~7% zerstörte Daten können korrigiert werden)
	M (middle, ~15% zerstörte Daten können korrigiert werden)
	Q (quality, ~25% zerstörte Daten können korrigiert werden)
	H (high, ~30% zerstörte Daten können korrigiert werden)
*/

$qrcecc="H";

/* Dicke eines zu zeichnenden Randes (=quiet zone, ein Randbereich ohne störende 
Elemente um Lesegeräten das Lokalisieren des QR-Codes zu erleichetern), Datenelemente 
als Maßeinheit. Das bedeutet, dass z.B. ein Wert von 1 dazu führt, dass ein Rand um 
den QR-Code gezeichnet wird, der genauso breit ist, wie ein Datenpixel/element des 
QR-Codes. Beachten Sie, dass der Rand die Farbe des Hintergrunds erhält (welche Sie 
via bgcolor setzen können) und nicht zur via size angegebenen Gesamtgröße dazu 
gerechnet wird. Außerdem wird der Rand zusätzlich zu einer ggf. vorhanden 
margin-Angabe gezeichnet. */

$qrcqzone="3";

/*
Dicke eines zu zeichnenden Randes in Pixel. Beachten Sie, dass der Rand die Farbe 
des Hintergrunds erhält (welche Sie via bgcolor setzen können) und nicht zur via 
size angegebenen Gesamtgrösse dazu gerechnet wird und daher auch nicht größer als 
ca. ein Drittel der size-Angabe sein darf. Auserdem wird der Rand zusätzlich zu 
einer ggf. vorhanden qzone-Angabe gezeichnet.
*/
$qrcmargin="5";

/* --------- Ende der Konfiguration ----------------------------------------- */
$qrcurl=urlencode($qrcurl);
$content ="<div class=\"block align-center\">";
$content .="<img src=\"http://api.qrserver.com/v1/create-qr-code/?data=".
				$qrcurl."&amp;size=".
				$qrcsize."x".$qrcsize."&amp;color=".
				$qrccolor."&amp;bgcolor=".$qrcbgcolor."&amp;ecc=".
				$qrcecc."&amp;qzone=".$qrcqzone."&amp;margin=".$qrcmargin."\"
				alt=\"".$qrctitle."\" 
				title=\"".$qrctitle."\" 
				/>";
$content .="</div>";
?>