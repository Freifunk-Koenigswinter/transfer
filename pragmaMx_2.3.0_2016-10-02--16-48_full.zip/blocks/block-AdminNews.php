<?php
/**
 * This file is part of
 * pragmaMx - Web Content Management System.
 * Copyright by pragmaMx Developer Team - http://www.pragmamx.org
 *
 * pragmaMx is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * $Revision: 6 $
 * $Author: PragmaMx $
 * $Date: 2015-07-08 09:07:06 +0200 (Mi, 08. Jul 2015) $
 */

defined('mxMainFileLoaded') or die('access denied');

global $prefix, $user_prefix, $themesetting;

if (!MX_IS_ADMIN && MX_IS_USER) {
    $udata = mxGetUserSession();
    if (list($aid) = sql_fetch_row(sql_query("SELECT aid FROM ${prefix}_authors WHERE user_uid=" . intval($udata[0])))) {
        $content = '<a href="' . adminUrl() . '">' . _AB_TITLEBAR . '</a>';
    }
    return;
}

if (!MX_IS_ADMIN) {
    return;
}

/* das Design der Liste ermitteln, ist im Prinzip das Gleiche wie in den Modulblöcken */
$class_ul = (isset($themesetting['blocknav']['style'])) ? $themesetting['blocknav']['style']: 'list';
$class_cu = (isset($themesetting['blocknav']['current'])) ? $themesetting['blocknav']['current']: 'current';

$mxblockcache = true;
$blockfiletitle = _AB_TITLEBAR;
$content = '';

$newentries = pmx_get_adminnews();
$item = array();
if ($newentries) {
	foreach ($newentries as $entry) {
		$item[] = '<a href="' . $entry['link'] . '"><strong>' . mxValueToString($entry['count'], 0) . '</strong>&nbsp;' . $entry['text'] . '</a>';
	}
}	
	$admindata = mxGetAdminData();
	extract($admindata);
	
	if ($radminsuper && !$item) {
		$content .= '<p class="note align-center">' . _AB_NOWAITINGCONT . '</p>';
	} else if ($item) {
		$content .= '<ul class="' . $class_ul . '"><li>' . implode("</li><li>", $item) . '</li></ul>';
	}
	
	$item = array();
	
	$item[] = '<a href="' . adminUrl() . '">' . _AB_TITLEBAR . '</a>';
	
	if ($radminsuper) {
		$item[] = '<a href="' . adminUrl('settings') . '">' . _AB_SETTINGS . '</a>';
		$item[] = '<a href="' . adminUrl('reset', 'cache') . '">' . _RESETPMXCACHE . '</a>';
	}
	$item[] = '<a href="' . adminUrl('logout') . '">' . _AB_LOGOUT . '</a>';
	
	$content .= '<ul class="' . $class_ul . '"><li>' . implode("</li><li>", $item) . '</li></ul>';

?>