<?php
/**
 * This file is part of
 * pragmaMx - Web Content Management System.
 * Copyright by pragmaMx Developer Team - http://www.pragmamx.org
 *
 * pragmaMx is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * $Revision: 6 $
 * $Author: PragmaMx $
 * $Date: 2015-07-08 09:07:06 +0200 (Mi, 08. Jul 2015) $
 */

defined('mxMainFileLoaded') or die('access denied');

/* --------- Konfiguration fuer den Block ----------------------------------- */

/* how many referers in block */
$numref = 10;

/* how long the length of URL to view */
$strlen = 16;

/* --------- Ende der Konfiguration ----------------------------------------- */

extract($block['settings'], EXTR_OVERWRITE);

global $prefix;

$mxblockcache = false;

$qry = "SELECT DISTINCT replace(url,'http://',''), url
FROM ${prefix}_referer
WHERE url<>'" . PMX_HOME_URL . "'
AND NOT LOCATE('" . PMX_HOME_URL . "', url)
ORDER BY rid DESC
LIMIT 0," . $numref . ";";

$result = sql_query($qry);
$content = '';
while (list($urls, $url) = sql_fetch_row($result)) {
    $url = htmlspecialchars(strip_tags($url));
    $urls = htmlspecialchars(strip_tags($urls));
    $url2 = mxCutString(str_replace("_", " ", $urls), $strlen);
    $content .= '<li><a href="' . $url . '" target="_blank" title="' . $url . '">' . $url2 . '</a></li>';
}

if ($content) {
    $content = '<ol class="list">' . $content . '</ol>';
    if (MX_IS_ADMIN) {
        $content .= '<p align="right"><a href="' . adminUrl('referers') . '">' . _READMORE . '</a></p>';
    }
}

?>