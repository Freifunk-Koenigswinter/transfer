<?php
/**
 * This file is part of
 * pragmaMx - Web Content Management System.
 * Copyright by pragmaMx Developer Team - http://www.pragmamx.org
 *
 * pragmaMx is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * $Revision: 32 $
 * $Author: PragmaMx $
 * $Date: 2015-07-23 18:30:51 +0200 (Do, 23. Jul 2015) $
 */

defined('mxMainFileLoaded') or die('access denied');

$mxblockcache = false;


/* verfuegbare der Sprachen ermitteln */
$languages = mxGetAvailableLanguages();
if (count($languages) < 2) {
    return;
}

ksort($languages);

/* aktuelle URL, als Basis fuer das Ziel */
$to = basename($_SERVER['PHP_SELF']);

/* index.php ist auch php_self=modules.php, */
/* deswegen hier index.php verwenden, falls $name leer ist */
if ($to == 'modules.php' && empty($_GET['name'])) {
    $to = 'index.php';
}

$args = array();
/* sicherstellen, dass der Modulname am Anfang steht (nur Optik) */
if (!empty($_GET['name'])) {
    $args[] = "name={$_GET['name']}";
}

/* die GET Parameter auslesen und (später) zu einem String zusammensetzen */
foreach($_GET as $key => $value) {
    // newlang und Modulname nicht nochmals anfügen
    if ($key != 'newlang' && $key != 'name') {
        $args[] = "{$key}={$value}";
    }
}
if ($args) {
    $to .= '?' . implode('&amp;', $args) . '&amp;newlang=';
} else {
    $to .= '?newlang=';
}

$content = _SELECTGUILANG . '<br /><br />';
if (empty($GLOBALS['useflags'])) {
    $content .= "<form action=\"index.php\" method=\"get\">";
    $content .= "<select name=\"newlanguage\" onchange=\"top.location.href=this.options[this.selectedIndex].value\">";
    foreach($languages as $alt => $langu) {
        $sel = ($langu == $GLOBALS['currentlang']) ? ' selected="selected" class="current"' : "";
        $content .= "<option value=\"" . $to . $langu . "\" " . $sel . ">" . $alt . "\n";
    }
    $content .= "</select></form>";
} else {
    $pre = "style=\"margin:3px;\"";
	
    foreach($languages as $alt => $langu) {
        $content .= "<a href=\"" . $to . $langu . "\" title=\"" . $alt . "\">" . mxCreateImage("images/language/flag-" . $langu . ".png", $alt, 0, $pre,true,false,false) . "</a> ";
    }
}

?>