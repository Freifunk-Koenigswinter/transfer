<?php
/**
 * This file is part of
 * pragmaMx - Web Content Management System.
 * Copyright by pragmaMx Developer Team - http://www.pragmamx.org
 *
 * pragmaMx is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * $Revision: 6 $
 * $Author: PragmaMx $
 * $Date: 2015-07-08 09:07:06 +0200 (Mi, 08. Jul 2015) $
 *
 * Das Template für diesen Block liegt HIER:
 * /layout/templates/includes/classes/Menu/block.html
 + oder im entsprechenden Ordner des eingestellten Themes
 */

defined('mxMainFileLoaded') or die('access denied');

if (!MX_IS_ADMIN) {
    return true;
}

/* Sprachdatei auswaehlen */
mxGetLangfile('admin');

$mxblockcache = false;

load_class('Menu', false);

$menu = pmxMenu::get_block_instance('adminmenu');

/* Verwendet dann pmxMenu_menu::_level() */
$content = $menu->fetch();
$menu = null;

?>