Dieser Ordner und seine Unterordner enthalten temporaere 
Daten und muessen vom PHP-System beschreibbar sein