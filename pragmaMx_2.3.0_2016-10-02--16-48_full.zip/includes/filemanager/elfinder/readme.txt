pragmaMx Dateimanager: elFinder 2.0-nightly
-------------------------------------------

Download:
 https://github.com/nao-pon/elFinder-nightly
 >> elfinder-2.1-*****.zip

ben�tigte Dateien und wohin damit?
 Im Zipfile liegt eventuell ein Unterordner "Studio-42-elFinder-xxxxxxx".
 Den Inhalt dieses Ordners hier in den Unterordner "manager" kopieren.
 Die beigef�gten Unterordner build, files und jquery werden nicht ben�tigt.

Konfiguration, siehe hier:
 https://github.com/Studio-42/elFinder/wiki
 ist aber unfertig und teils �berholt, ist eben ne beta...

