<?php
/**
 * pragmaMx - Web Content Management System
 * Copyright by pragmaMx Developer Team - http://www.pragmamx.org
 * written with: $Id: settings.php 237 2016-09-29 13:13:55Z PragmaMx $
 */

defined('mxMainFileLoaded') or die('access denied');

$passphraselenght = 4;
$charstouse = '23456789abcdfghjkmnpqrstvwxABCDEFGHJKLMNPRSTUVWXYZ';
$casesensitive = 0;
$imagewidth = 140;
$imageheight = 40;
$fontsize = 24;
$bgintensity = 40;
$bgfonttype = 3;
$scratchamount = 30;
$filter = 0;
$filtertype = 'Wavy';
$scratches = 1;
$addagrid = 1;
$addhorizontallines = 1;
$useRandomColors = 1;
$minsize = 24;
$angle = 15;
$captchasession = 1;
$captchauseron = 1;
$commentson = 1;
$feedbackon = 1;
$faqon = 1;
$downloadson = 1;
$weblinkson = 1;
$guestbookon = 1;
$newson = 1;
$newsletteron = 1;
$reviewson = 1;
$recommendon = 1;
$registrationon = 1;
$documentson = 1;
$contacton = 1;
$infoon = 1;
$siriusgalleryon = 1;
$beliebigon = 1;

?>