Dieser Ordner enth�lt die originalen Plugins und Filter, 
sowie das Savant Formular-Plugin.

Anpassungen der bestehenden Plugins, oder zus�tzliche Plugins/Filter, 
sollten im Ordner /includes/savant/plugins gespeichert werden.
Diese werden dann bevorzugt verwendet.