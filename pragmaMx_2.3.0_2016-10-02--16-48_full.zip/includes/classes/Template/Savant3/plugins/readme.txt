Dieser Ordner enth�lt angepasste oder zus�tzliche 
Plugins und Filter f�r die Savant Template Engine.