---------
 Mystique
---------

Ein tabellenloses, dreispaltiges XHTML-Theme mit fester, oder wahlweise 
flexibler Breite.
Das Theme l�sst sich �ber eine Konfigurationsdatei (theme.settings.php) und das 
HTML-Template sehr einfach anpassen.

Das Design basiert auf dem Mystique XHTML/CSS Template von digitalnature.
http://digitalnature.eu/
http://digitalnature.eu/projects/mystique/
Es ist unter der GPL-Lizenz lizensiert die diesem Downloadpaket beiliegt.

Das Theme ist nur lauff�hig ab pragmaMx 1.12 sowie mindestens 
PHP-Version 5.2 und erfordert eine XHTML-Doctype Einstellung. Fragen zur 
Anpassung oder bei Problemen bitte im pragmaMx-Forum stellen: 
http://www.pragmamx.org/Forum-board-109.html

Zur Konfiguration des Themes lesen sie bitte die beiliegende settings.html.

viel Spass,
Ihr pragmaMx-Team...

