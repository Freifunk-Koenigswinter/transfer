<?php
/**
 * pragmaMx - Web Content Management System.
 * Copyright by pragmaMx Developer Team - http://www.pragmamx.org
 * $Id: layout.fixed.css.php,v 1.2 2012-02-19 18:31:08 tora60 Exp $
 */

define('mxMainFileLoaded', 1);

/* CSS Header senden */
header('Content-Type: text/css');
header('X-Powered-By: pragmaMx-cms');
header('Expires: ' . gmdate('D, d M Y H:i:s', time() + 3600 * 24) . ' GMT'); // 1 day
header('Last-Modified: ' . gmdate('D, d M Y H:i:s', filemtime('../theme.settings.php')) . ' GMT');
header('Etag: ' . md5(filemtime('../theme.settings.php')));

/* default widths - fixed - 960gs  */
$defaults = array(/* Breiten */
    'min' => 780,
    'max' => 1200,
    'page' => 960,
    'left' => 207,
    'right' => 207,
    );

error_reporting(0);
include('../theme.settings.php');
error_reporting(E_ALL);
$min = intval((isset($themesetting['layoutwidth']['min'])) ? $themesetting['layoutwidth']['min'] : $defaults['min']);
$max = intval((isset($themesetting['layoutwidth']['max'])) ? $themesetting['layoutwidth']['max'] : $defaults['max']);
$page = intval((isset($themesetting['layoutwidth']['page_fixed'])) ? $themesetting['layoutwidth']['page_fixed'] : $defaults['page']);
$left = intval((isset($themesetting['layoutwidth']['left_fixed'])) ? $themesetting['layoutwidth']['left_fixed'] : $defaults['left']);
$right = intval((isset($themesetting['layoutwidth']['right_fixed'])) ? $themesetting['layoutwidth']['right_fixed'] : $defaults['right']);

if (!$page || $page < $min || $page > $max) {
    $page = $defaults['page'];
}
if ($left > $page / 2) {
    $left = $defaults['left'];
}
if ($right > $page / 2) {
    $right = $defaults['right'];
}

ob_start();

?>
<style>
<!--
<?php ob_end_clean() ?>

#sidebar-left {
   width: <?php echo $left ?>px;
}

#sidebar-right {
   width: <?php echo $right ?>px;
}

.page-content {
   margin: 0 auto; /* (max. possible width is limited by design, 1735px)  */
   max-width: <?php echo $max ?>px;
   min-width: <?php echo $min ?>px;
   width: <?php echo $page ?>px;
}

.col-1 #mainbar {
   left: 0;
   width: <?php echo $page ?>px;
}

.col-1 #sidebar-right,
.col-1 #sidebar-left {
   display: none;
}

.col-1 #mainbar .block.__BLOCK_ID__ {
<?php /* z.B. Blockvorschau im Adminmenue */ ?>
width: <?php echo $left ?>%;
}

.col-2-left #mainbar {
   left: <?php echo $left ?>px;
   width: <?php echo $page - $left ?>px;
}

.col-2-left #sidebar-left {
   display: block;
   right: <?php echo $page - $left ?>px;
}

.col-2-left #sidebar-right {
   display: none;
}

.col-2-left.col-to-right #mainbar {
   left: 0;
}

.col-2-left.col-to-right #sidebar-left {
   right: 0;
}

.col-2-right #mainbar {
   left: 0;
   width: <?php echo $page - $right ?>px;
}

.col-2-right #sidebar-left {
   display: none;
}

.col-2-right #sidebar-right {
   right: 0;
}

.col-2-right.col-to-left #mainbar {
   left: <?php echo $right ?>px;
}

.col-2-right.col-to-left #sidebar-right {
   right: <?php echo $page - $right ?>px;
}

.col-3 #mainbar {
   left: <?php echo $left ?>px;
}

.col-3 #mainbar,
.col-3-left #mainbar,
.col-3-right #mainbar {
   width: <?php echo $page - $left - $right ?>px;
}

.col-3 #sidebar-left,
.col-3-left #sidebar-right,
.col-3-left #sidebar-left {
   left: -<?php echo $page - $left - $right ?>px;
}

.col-3 #sidebar-right {
   right: 0;
}

.col-3-left #mainbar {
   left: <?php echo $left + $right ?>px;
}

.col-3-left #mainbar .blocks {
   xxxmargin-left: 10px;
}

.col-3-right #mainbar {
   left: 0;
}

.col-3-right #mainbar .blocks {
   xxxmargin-right: 10px;
}

.col-3-right #sidebar-left {
   left: <?php echo $right ?>px;
}

.col-3-right #sidebar-right {
   left: -<?php echo $left ?>px;
}

<?php return ?>
-->
</style>

