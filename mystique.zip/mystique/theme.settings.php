<?php
/**
 * pragmaMx - Web Content Management System.
 * Copyright by pragmaMx Developer Team - http://www.pragmamx.org
 *
 * $Revision: 1.8 $
 * $Author: tora60 $
 * $Date: 2012-02-19 18:11:26 $
 */

/* diese Zeile nicht aendern!! */
defined('mxMainFileLoaded') or die('access denied');

/**
 * der Titel im Kopfbereich der Seite
 */
$themesetting['title'] = $GLOBALS['sitename'];

/**
 * der Untertitel/Slogan im Kopfbereich der Seite
 */
$themesetting['slogan'] = $GLOBALS['slogan'];

/**
 * Layout-Columns: default, left, right
 * .                 |-|     ||-    -||
 */
$themesetting['layoutcols'] = 'default';

/**
 * Layout-Typ: fluid oder fixed
 */
$themesetting['layouttype'] = 'fluid';

/**
 * Farbschema: blue, green, grey, red
 */
$themesetting['colorscheme'] = 'green';

/**
 * URL zur eigenen Twitter-Seite
 * '##' angeben, um den Link zu verstecken
 */
$themesetting['twitterlink'] = 'http://twitter.com/digitalnature';

/**
 * URL zum RSS-Feed der Seite
 * '##' angeben, um den Link zu verstecken
 */
$themesetting['rsslink'] = 'backend.php?mod=News'; # backend.php

/**
 * das Men� im Kopfbereich  (erst ab pragmaMx 1.12!)
 * - den Men�namen aus dem Men�manager angeben, oder
 * - leer lassen (false) um das weiter unten definierte Men� zu verwenden
 */
$themesetting['head_css_menu'] = '{CSS-MENU}'; // z.B.: {CSS-MENU}

/* folgendes nur, wenn Module geladen */
if (defined('MX_MODULE')) {
    /**
     * Seiten, bei denen, die linken Bloecke nicht gezeigt werden sollen
     */
    $themesetting['hide-left'] = array(/* Seiten/Module */
        // MX_MODULE == 'Downloads',
        // MX_MODULE == 'FAQ',
        // MX_MODULE == 'Downloads' && $_REQUEST['cid'] == 61, // Downloads, Kategorie 61
        // $_REQUEST['name'] == 'Content' && $_REQUEST['pid'] == 28, // Contentmodul Id 28
        );

    /**
     * Seiten, bei denen beide Blockspalten nicht angezeigt werden sollen
     */
    $themesetting['hide-both'] = array(/* Seiten/Module */
        MX_MODULE == 'admin',
        // MX_MODULE === 'Gallery',
        // MX_MODULE == 'coppermine',
        MX_MODULE == 'Forum',
        // MX_MODULE == 'eboard',
        // MX_MODULE == 'Downloads' && $_REQUEST['cid'] == 61, // Downloads, Kategorie 61
        // $_REQUEST['name'] == 'Content' && $_REQUEST['pid'] == 28, // Contentmodul Id 28
        );
}
/* Ende nur Module */

/**
 * Banner im theme anzeigen
 */
$themesetting['banner_head'] = false; // im Kopfbereich
$themesetting['banner_foot'] = false; // im Fussbereich

/**
 * Link zur Hilfe zur Themekonfiguration anzeigen
 * true = ja, false = nein
 */
$themesetting['theme_help'] = true;

/**
 * folgende Einstellungen sollten nicht veraendert werden
 */

/* Modul-Bloecke im passenden Design anzeigen */
$themesetting['blocknav']['style'] = 'menu';
$themesetting['blocknav']['current'] = 'current';

/* definieren ob die Templates des Themes gecached werden koennen */
define('MX_THEME_CACHABLE', true);

/* Dateiname des templates */
define('MX_THIS_THEMEFILE', 'theme.html');

?>
