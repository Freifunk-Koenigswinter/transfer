if (isIE == 'undefined') var isIE = false;
if (isIE6 == 'undefined') var isIE6 = false;

/* twitter functions  */
/* http://jquery-howto.blogspot.com/2009/04/jquery-twitter-api-plugin.html */
(function (jQuery) {
  jQuery.extend({
    jTwitter: function (username, fnk) {
      var url = "http://twitter.com/status/user_timeline/" + username + ".json?count=1&callback=?";
      var info = {};
      jQuery.getJSON(url, function (data) {
        if (typeof fnk == 'function') fnk.call(this, data[0].user);
      });
    }
  });
})(jQuery); /* http://tweet.seaofclouds.com/ */
(function (jQuery) {
  jQuery.fn.getTwitter = function (o) {
    var s = {
      username: ["wordpress"],
      // [string]   required, unless you want to display our tweets. :) it can be an array, just do ["username1","username2","etc"]
      avatar_size: null,
      // [integer]  height and width of avatar if displayed (48px max)
      count: 6,
      // [integer]  how many tweets to display?
      loading_text: null,
      // [string]   optional loading text, displayed while tweets load
      query: null // [string]   optional search query
    };
    jQuery.fn.extend({
      linkUrl: function () {
        var returning = [];
        var regexp = /((ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?)/gi;
        this.each(function () {
          returning.push(this.replace(regexp, "<a href=\"$1\">$1</a>"))
        });
        return jQuery(returning);
      },
      linkUser: function () {
        var returning = [];
        var regexp = /[\@]+([A-Za-z0-9-_]+)/gi;
        this.each(function () {
          returning.push(this.replace(regexp, "<a href=\"http://twitter.com/$1\">@$1</a>"))
        });
        return jQuery(returning);
      },
      linkHash: function () {
        var returning = [];
        var regexp = / [\#]+([A-Za-z0-9-_]+)/gi;
        this.each(function () {
          returning.push(this.replace(regexp, ' <a href="http://search.twitter.com/search?q=&tag=$1&lang=all&from=' + s.username.join("%2BOR%2B") + '">#$1</a>'))
        });
        return jQuery(returning);
      },
      capAwesome: function () {
        var returning = [];
        this.each(function () {
          returning.push(this.replace(/(a|A)wesome/gi, 'AWESOME'))
        });
        return jQuery(returning);
      },
      capEpic: function () {
        var returning = [];
        this.each(function () {
          returning.push(this.replace(/(e|E)pic/gi, 'EPIC'))
        });
        return jQuery(returning);
      },
      makeHeart: function () {
        var returning = [];
        this.each(function () {
          returning.push(this.replace(/[&lt;]+[3]/gi, "<tt class='heart'>&#x2665;</tt>"))
        });
        return jQuery(returning);
      }
    });
    function relative_time(time_value) {
      var parsed_date = Date.parse(time_value);
      var relative_to = (arguments.length > 1) ? arguments[1] : new Date();
      var delta = parseInt((relative_to.getTime() - parsed_date) / 1000);
      if (delta < 60) {
        return 'less than a minute ago';
      } else if (delta < 120) {
        return 'about a minute ago';
      } else if (delta < (45 * 60)) {
        return (parseInt(delta / 60)).toString() + ' minutes ago';
      } else if (delta < (90 * 60)) {
        return 'about an hour ago';
      } else if (delta < (24 * 60 * 60)) {
        return 'about ' + (parseInt(delta / 3600)).toString() + ' hours ago';
      } else if (delta < (48 * 60 * 60)) {
        return '1 day ago';
      } else {
        return (parseInt(delta / 86400)).toString() + ' days ago';
      }
    }
    if (o) jQuery.extend(s, o);
    return this.each(function () {
      var list = jQuery('<ul class="tweet_list">').appendTo(this);
      list.hide();
      var loading = jQuery('<div class="loading">' + s.loading_text + '</div>');
      if (typeof(s.username) == "string") {
        s.username = [s.username];
      }
      var query = '';
      if (s.query) {
        query += 'q=' + s.query;
      }
      query += '&q=from:' + s.username.join('%20OR%20from:');
      var url = 'http://search.twitter.com/search.json?&' + query + '&rpp=' + s.count + '&callback=?';
      if (s.loading_text) jQuery(this).append(loading);
      jQuery.getJSON(url, function (data) {
        if (s.loading_text) loading.remove();
        jQuery.each(data.results, function (i, item) {
          var avatar_template = '<a class="tweet_avatar" href="http://twitter.com/' + item.from_user + '"><img src="' + item.profile_image_url + '" height="' + s.avatar_size + '" width="' + s.avatar_size + '" alt="' + item.from_user + '\'s avatar" border="0"/></a>';
          var avatar = (s.avatar_size ? avatar_template : '')
          var date = '<a class="date" href="http://twitter.com/' + item.from_user + '/statuses/' + item.id + '" title="view tweet on twitter">' + relative_time(item.created_at) + '</a>';
          var text = '<span class="entry">' + jQuery([item.text]).linkUrl().linkUser().linkHash().makeHeart().capAwesome().capEpic()[0] + date + '</span>';
          // until we create a template option, arrange the items below to alter a tweet's display.
          list.append('<li>' + text + '</li>');
          list.children('li:first').addClass('firstTweet');
          list.children('li:odd').addClass('even');
          list.children('li:even').addClass('lastTweet');
        });
        list.animate({
          opacity: 'toggle',
          height: 'toggle'
        }, 500, 'easeOutQuart');
      });
    });
  };
})(jQuery);
// nundge effect
jQuery.fn.nudge = function (params) { //set default parameters
  params = jQuery.extend({
    amount: 20,
    //amount of pixels to pad / marginize
    duration: 300,
    //amount of milliseconds to take
    property: 'padding',
    //the property to animate (could also use margin)
    direction: 'left',
    //direction to animate (could also use right)
    toCallback: function () {},
    //function to execute when MO animation completes
    fromCallback: function () {} //function to execute when MOut animation completes
  }, params); //For every element meant to nudge...
  this.each(function () { //variables
    var $t = jQuery(this);
    var $p = params;
    var dir = $p.direction;
    var prop = $p.property + dir.substring(0, 1).toUpperCase() + dir.substring(1, dir.length);
    var initialValue = $t.css(prop); /* fx */
    var go = {};
    go[prop] = parseInt($p.amount) + parseInt(initialValue);
    var bk = {};
    bk[prop] = initialValue; //Proceed to nudge on hover
    $t.hover(function () {
      $t.stop().animate(go, $p.duration, '', $p.toCallback);
    }, function () {
      $t.stop().animate(bk, $p.duration, '', $p.fromCallback);
    });
  });
  return this;
};
// bubble
(function (jQuery) {
  jQuery.fn.bubble = function (options) {
    jQuery.fn.bubble.defaults = {
      timeout: 0,
      offset: 22
    };
    var o = jQuery.extend({}, jQuery.fn.bubble.defaults, options);
    return this.each(function () {
      var showTip = function () {
        var el = jQuery(this).find('.bubble').css('display', 'block')[0];
        var ttHeight = jQuery(el).height();
        var ttOffset = el.offsetHeight;
        var ttTop = ttOffset + ttHeight;
        jQuery(this).find('.bubble').stop().css({
          'opacity': 0,
          'top': 2 - ttOffset
        }).animate({
          'opacity': 1,
          'top': o.offset - ttOffset
        }, 250);
      };
      var hideTip = function () {
        var self = this;
        var el = jQuery('.bubble', this).css('display', 'block')[0];
        var ttHeight = jQuery(el).height();
        var ttOffset = el.offsetHeight;
        var ttTop = ttOffset + ttHeight;
        jQuery(this).find('.bubble').stop().animate({
          'opacity': 0,
          'top': 12 - ttOffset
        }, 250, 'swing', function () {
          el.hiding = false;
          jQuery(this).css('display', 'none');
        })
      }
      jQuery(this).find('.bubble').hover(function () {
        return false;
      }, function () {
        return true;
      });
      jQuery(this).hover(function () {
        var self = this;
        showTip.apply(this);
        if (o.timeout > 0) this.tttimeout = setTimeout(function () {
          hideTip.apply(self)
        }, o.timeout);
      }, function () {
        clearTimeout(this.tttimeout);
        hideTip.apply(this);
      });
    });
  };
})(jQuery);
//Private function for setting cookie

function updateCookie(target, data) {
  var cookie = target.replace(/[#. ]/g, '');
  jQuery.cookie(cookie, data, {
    path: '/'
  });
}
function fontControl(container, target, minSize, maxSize) {
  jQuery(container).append('<a href="javascript:void(0);" class="fontsize bubble" title="Increase or decrease text size"></a>');
  var cookie = 'page-font-size';
  var value = jQuery.cookie(cookie);
  if (value != null) {
    jQuery(target).css('fontSize', parseInt(value));
  } //on clicking small font button, font size is decreased by 1px
  jQuery(container + " .fontsize").click(function () {
    curSize = parseInt(jQuery(target).css("fontSize"));
    newSize = curSize + 1;
    if (newSize > maxSize) newSize = minSize;
    if (newSize >= minSize) //jQuery(target).css('fontSize', newSize);
    jQuery(target).animate({
      fontSize: newSize
    }, 333, 'swing');
    updateCookie(cookie, newSize); //sets the cookie
  });
}
/*
 * Superfish v1.4.8 - jQuery menu widget
 * Copyright (c) 2008 Joel Birch
 *
 * Dual licensed under the MIT and GPL licenses:
 * 	http://www.opensource.org/licenses/mit-license.php
 * 	http://www.gnu.org/licenses/gpl.html
 *
 * CHANGELOG: http://users.tpg.com.au/j_birch/plugins/superfish/changelog.txt

- MODIFIED FOR MYSTIQUE! BE CAREFUL WHEN UPDATING!

 */
;
(function (jQuery) {
  jQuery.fn.superfish = function (op) {
    var sf = jQuery.fn.superfish,
      c = sf.c,
      $arrow = jQuery(['<span class="', c.arrowClass, '"> &#187;</span>'].join('')),
      over = function () {
        var $$ = jQuery(this),
          menu = getMenu($$);
        clearTimeout(menu.sfTimer);
        $$.showSuperfishUl().siblings().hideSuperfishUl();
      },
      out = function () {
        var $$ = jQuery(this),
          menu = getMenu($$),
          o = sf.op;
        clearTimeout(menu.sfTimer);
        menu.sfTimer = setTimeout(function () {
          o.retainPath = (jQuery.inArray($$[0], o.$path) > -1);
          $$.hideSuperfishUl();
          if (o.$path.length && $$.parents(['li.', o.hoverClass].join('')).length < 1) {
            over.call(o.$path);
          }
        }, o.delay);
      },
      getMenu = function ($menu) {
        var menu = $menu.parents(['ul.', c.menuClass, ':first'].join(''))[0];
        sf.op = sf.o[menu.serial];
        return menu;
      },
      addArrow = function ($a) {
        $a.addClass(c.anchorClass).append($arrow.clone());
      };
    return this.each(function () {
      var s = this.serial = sf.o.length;
      var o = jQuery.extend({}, sf.defaults, op);
      o.$path = jQuery('li.' + o.pathClass, this).slice(0, o.pathLevels).each(function () {
        jQuery(this).addClass([o.hoverClass, c.bcClass].join(' ')).filter('li:has(ul)').removeClass(o.pathClass);
      });
      sf.o[s] = sf.op = o;
      jQuery('li:has(ul)', this)[(jQuery.fn.hoverIntent && !o.disableHI) ? 'hoverIntent' : 'hover'](over, out).each(function () {
        if (o.autoArrows) addArrow(jQuery('>a:first-child', this));
      }).not('.' + c.bcClass).hideSuperfishUl();
      var $a = jQuery('a', this);
      $a.each(function (i) {
        var $li = $a.eq(i).parents('li');
        $a.eq(i).focus(function () {
          over.call($li);
        }).blur(function () {
          out.call($li);
        });
      });
      o.onInit.call(this);
    }).each(function () {
      var menuClasses = [c.menuClass];
      jQuery(this).addClass(menuClasses.join(' '));
    });
  };
  var sf = jQuery.fn.superfish;
  sf.o = [];
  sf.op = {};
  sf.c = {
    bcClass: 'sf-breadcrumb',
    menuClass: 'sf-js-enabled',
    anchorClass: 'sf-with-ul',
    arrowClass: 'arrow'
  };
  sf.defaults = {
    hoverClass: 'sfHover',
    pathClass: 'overideThisToUse',
    pathLevels: 1,
    delay: 500,
    speed: 'normal',
    autoArrows: true,
    disableHI: false,
    // true disables hoverIntent detection
    onInit: function () {},
    // callback functions
    onBeforeShow: function () {},
    onShow: function () {},
    onHide: function () {}
  };
  jQuery.fn.extend({
    hideSuperfishUl: function () {
      var o = sf.op,
        not = (o.retainPath === true) ? o.$path : '';
      o.retainPath = false;
      if (isIE) {
        css1 = {
          marginLeft: 20
        };
      } else {
        css1 = {
          opacity: 0,
          marginLeft: 20
        };
      }
      var $ul = jQuery(['li.', o.hoverClass].join(''), this).add(this).not(not).removeClass(o.hoverClass).find('>ul').animate(css1, 150, 'swing', function () {
        jQuery(this).css({
          display: "none"
        })
      });
      o.onHide.call($ul);
      return this;
    },
    showSuperfishUl: function () {
      var o = sf.op,
        $ul = this.addClass(o.hoverClass).find('>ul:hidden').css('visibility', 'visible');
      o.onBeforeShow.call($ul);
      if (isIE) {
        css1 = {
          display: "block",
          marginLeft: 20
        };
        css2 = {
          marginLeft: 0
        };
      } else {
        css1 = {
          display: "block",
          opacity: 0,
          marginLeft: 20
        };
        css2 = {
          opacity: 1,
          marginLeft: 0
        };
      }
      $ul.css(css1).animate(css2, 150, 'swing', function () {
        o.onShow.call($ul);
      });
      return this;
    }
  });
})(jQuery);
// init
jQuery(document).ready(function ($) {
  if (isIE6) {
    jQuery('#page').append("<div class='crap-browser-warning'>You're using a old and buggy browser. Switch to a <a href='http://www.mozilla.com/firefox/'>normal browser</a> or consider <a href='http://www.microsoft.com/windows/internet-explorer'>upgrading your Internet Explorer</a> to the latest version</div>");
  }
  jQuery('#navigation').superfish({
    autoArrows: true
  });
  // layout controls
  fontControl("#pagecontrols", "body", 10, 18);
  jQuery("ul.menulist .cat-item").bubble({
    timeout: 6000
  });
  jQuery("#pagecontrols").bubble({
    offset: 30
  });
  jQuery('ul.menulist li a').nudge({
    property: 'padding',
    direction: 'left',
    amount: 6,
    duration: 166
  });
  jQuery('a.nav-extra').nudge({
    property: 'marginTop',
    direction: '',
    amount: -12,
    duration: 166
  });
  // fade effect
  if (!isIE) {
    jQuery('.fadethis').append('<span class="hover"></span>').each(function () {
      var jQueryspan = jQuery('> span.hover', this).css('opacity', 0);
      jQuery(this).hover(function () {
        jQueryspan.stop().fadeTo(333, 1);
      }, function () {
        jQueryspan.stop().fadeTo(333, 0);
      });
    });
  }
  // scroll to top
  jQuery('a.toplink').click(function () {
    jQuery('html').animate({
      scrollTop: 0
    }, 'slow');
    return false;
  });
  // set accessibility roles on some elements trough js (to not break the xhtml markup)
  jQuery("#navigation").attr("role", "navigation");
  jQuery("#mainbar").attr("role", "main");
  jQuery("#sidebar-left, #sidebar-right").attr("role", "complementary");
  jQuery("#searchform").attr("role", "search");
});