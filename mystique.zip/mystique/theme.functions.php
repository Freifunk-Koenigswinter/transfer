<?php
/**
 * pragmaMx - Web Content Management System.
 * Copyright by pragmaMx Developer Team - http://www.pragmamx.org
 *
 * $Revision: 1.13 $
 * $Author: tora60 $
 * $Date: 2012-03-01 22:53:17 $
 */

defined('mxMainFileLoaded') or die('access denied');

/**
 * Definition der jeweiligen Platzhalter und deren Ersetzungen
 */
function theme_define_placeholders()
{
    global $themesetting;
    // {LAYOUT_CLASS} wird in theme_header eingetragen, nicht hier !!
    $part[] = array("{PAGE_TITLE}", $themesetting['title']);
    $part[] = array("{PAGE_SLOGAN}", $themesetting['slogan']);
    $part[] = array("{LINK_RSSFEED}", $themesetting['rsslink']);
    $part[] = array("{LINK_TWITTER}", $themesetting['twitterlink']);
    $part[] = array("{FOOTMESSAGE}", theme_show_footmsg());
    $part[] = array("{DEBUGSERVICE}", theme_get_servicetext('debugservice'));
    $part[] = array("{SITESERVICE}", theme_get_servicetext('siteservice'));
    $part[] = array("{NAVBAR}", theme_get_mxmenu());

    if ($themesetting['banner_head']) {
        $part[] = array("{BANNER_HEAD}", theme_show_banner(1)); # 1 = HeaderBanner
    }

    if ($themesetting['banner_foot']) {
        $part[] = array("{BANNER_FOOT}", theme_show_banner(2)); # 2 = FooterBanner
    }

    $doctype_arr = mxDoctypeArray($GLOBALS['DOCTYPE']);
    list($type, $number) = explode(' ', $doctype_arr['name']);
    if (is_numeric($number)) {
        $type .= '&nbsp;' . $number;
    }

    $part[] = array("{XHTML}", $type);

    return $part;
}

/**
 * Definition der einzelnen Blockbereiche
 */
function theme_define_blocks()
{
    global $themesetting;
    static $var;
    if (isset($var)) return $var;
    // linke Bloecke
    $name = 'block_left';
    $var[$name]['container'] = 'blocks_left_loop';
    $var[$name]['function'] = 'themesidebox';
    $var[$name]['position'] = 'l';
    // obere Center-Bloecke
    $name = 'block_center_top';
    $var[$name]['container'] = 'blocks_center_top_loop';
    $var[$name]['function'] = 'thememiddlebox';
    $var[$name]['position'] = 'c';
    // untere Center-Bloecke
    $name = 'block_center_down';
    $var[$name]['container'] = 'blocks_center_down_loop';
    $var[$name]['function'] = 'thememiddlebox';
    $var[$name]['position'] = 'd';
    // rechte Bloecke
    $name = 'block_right';
    $var[$name]['container'] = 'blocks_right_loop';
    $var[$name]['function'] = 'themesidebox';
    $var[$name]['position'] = 'r';
    return $var;
}

/**
 * Definition des Contentbereiches inkl. der open/close-Table Funktionen
 */
function theme_define_content()
{
    static $var;
    if (isset($var)) return $var;
    // die Funktion OpenTable()
    $var['opentabs']['OpenTable']['templatevar'] = 'opentable';
    $var['opentabs']['OpenTable']['innerreplace'] = '{OPENCLOSE_TABLE}'; // hier kann irgendwas stehen, es muss aber mit dem entsprechenden Text innerhalb der template-Datei uebereinstimmen...
    // die Funktion OpenTable2()
    $var['opentabs']['OpenTable2']['templatevar'] = 'opentable2';
    $var['opentabs']['OpenTable2']['innerreplace'] = '{OPENCLOSE_TABLE_2}';
    // die Funktion OpenTableAl()
    $var['opentabs']['OpenTableAl']['templatevar'] = 'opentableal';
    $var['opentabs']['OpenTableAl']['innerreplace'] = '{OPENCLOSE_TABLE_AL}';
    // die Funktion themeindex() / News Modul
    $var['themeindex'] = 'themeindex';
    // die Funktion themearticle() / News Modul
    $var['themearticle'] = 'themearticle';
    // der Name (output_container) darf nicht veraendert werden !!
    $var['output_container'] = 'script_output';
    // der Name (index_on_container) darf nicht veraendert werden !!
    $var['index_on_container'] = 'blocks_right_container';
    $var['index_on_block_container'] = 'blocks_right_loop';
    // der Name (more_header) darf nicht veraendert werden !!
    $var['add_header'] = 'more_header';

    return $var;
}

/**
 * Die verschiedenen Layout-Spalten definieren
 * das Ganze wird in Funktion theme_header() angewendet
 */
function theme_get_layout_class()
{
    global $themesetting;

    $class = '';

    switch ($themesetting['layouttype']) {
        case 'fluid':
            $class .= ' fluid';
            break;
        case 'fixed':
        default:
            $class .= ' fixed';
    }

    switch (true) {
        case theme_hidesideblocks():
        case theme_hiderightblocks() && theme_hideleftblocks():
            // einspaltiges Layout
            $class .= ' col-1';
            break;

        case theme_hiderightblocks():
        case isset($_GET['about']) && $_GET['about'] === basename(_THISTHEME_):
            // zweispaltiges Layout
            $class .= ' col-2-left';
            if ($themesetting['layoutcols'] == 'right') {
                $class .= ' col-to-right';
            }
            break;

        case theme_hideleftblocks():
            // zweispaltiges Layout, rechts ist aber links!!
            $class .= ' col-2-right';
            if ($themesetting['layoutcols'] == 'left') {
                $class .= ' col-to-left';
            }
            break;

        default:
            // dreispaltiges Layout > Standard
            switch ($themesetting['layoutcols']) {
                case 'left':
                    $class .= ' col-3-left';
                    break;
                case 'right':
                    $class .= ' col-3-right';
                    break;
                default:
                    $class .= ' col-3';
            }
            break;
    }
    $class .= ' bodymain';
    $class .= ' ' . $themesetting['colorscheme'];

    return trim($class);
}

/**
 * ersetzen von eigenen Theme-Elementen, kann veraendert und ergaenzt werden
 * diese Teile werden gleich zu Beginn des scriptes, beim einlesen des templates, ersetzt
 * Vorsicht, wenn das Theme gecached werden soll!!!
 * Dann duerfen hier keine dynamischen Elemente eingesetzt werden.
 */
function theme_replace_start($template)
{
    global $themesetting;

    /**
     * bestimmte Texte, vor allem Image-Pfade, die ersetzt werden sollen, definieren (suche/ersetze)
     */
    $part[] = array('"style/', '"' . MX_THEME_DIR . '/style/'); // die Stylesheets
    $part[] = array('"js/', '"' . MX_THEME_DIR . '/js/'); // die Javascripte
    $part[] = array('"images/', '"' . MX_THEME_DIR . '/images/'); // normale images im theme

    // Siteservicebereich entfernen, wenn Siteservice abgeschaltet oder leer ist
    if (!theme_get_servicetext('siteservice')) {
        theme_extract_part($template, 'siteservice', '');
    }
    // Debugbereich entfernen, wenn Debugmodus abgeschaltet oder leer ist
    if (!theme_get_servicetext('debugservice')) {
        theme_extract_part($template, 'debugservice', '');
    }
    // das Kopfmenue durch die tatsaechlichen Daten ersetzen
    theme_extract_part($template, 'headmenue', '{NAVBAR}');
    $part[] = array('{CLASS}' , theme_get_layout_class());

    if (!$themesetting['banner_head']) {
        theme_extract_part($template, 'banner_head');
    }

    if (!$themesetting['banner_foot']) {
        theme_extract_part($template, 'banner_foot');
    }

    return theme_replace_parts($template, $part);
}

/**
 * ersetzen von eigenen Theme-Elementen, kann veraendert und ergaenzt werden
 * diese Teile werden vor der Ausgabe des headers im Headbereich ersetzt
 */
function theme_replace_header($newheader)
{
    /* bei Bedarf den XHTML-Dokumenttyp ueberpruefen und Fehlermeldung ausgeben */
    if (MX_IS_ADMIN && !theme_check_xhtmldoctype()) {
        $newheader .= '<div class="warning"><h2 class="align-center">' . _THEME_FALSEDOCTYPE . '</h2></div>';
    }

    return $newheader;
}

/**
 * ersetzen in jedem einzelnen Block
 */
function theme_replace_blocks($template, $block)
{
    global $themesetting;

    /* Teil fuer alle Bloecke */
    if (empty($block['title']) || $block['title'] == 'NOTITLE') {
        $part[] = array('__BLOCK_ID__' , '__BLOCK_ID__ block-hide-caption');
        $part[] = array('<span></span>' , '');
    }
    $part[] = array('__BLOCK_ID__' , 'block-' . $block['position'] . '-' . $block['order'] . '-bid-' . $block['bid'] . '');

    return theme_replace_parts($template, $part);
}

/**
 * ersetzen von eigenen Theme-Elementen, kann veraendert und ergaenzt werden
 * diese Teile werden am Ende des scriptes, in der Funktion themefooter() ersetzt
 */
function theme_replace_end($template)
{
    global $themesetting;

    /* die linken Bloecke bei bestimmten Seiten entfernen */
    if (theme_hideleftblocks()) {
        theme_extract_part($template, 'blocks_left_container');
    }

    /* Hilfebutton nur bei Admins einblenden */
    switch (true) {
        case !MX_IS_ADMIN:
        case !mxGetAdminPref('radminsuper'):
        case empty($themesetting['theme_help']):
            theme_extract_optional_part($template, 'themehelp', '');
            break;
        case isset($_GET['about']) && $_GET['about'] === basename(_THISTHEME_):
            $content = theme_help();
            if ($content) {
                theme_extract_optional_part($template, 'Content', $content);
            }
            break;
    }

    /* Leere Elemente entfernen */
    $part[] = array('<h2 class="title"><a rel="bookmark"></a></h2>', '');
    $part[] = array('<h2 class="title"><a href="#" rel="bookmark"></a></h2>', '');
    $part[] = array('<h3 class="title"></h3>', '');
    $part[] = array('<h2 class="title"></h2>', '');

    return theme_replace_parts($template, $part);
}

/**
 * pruefen ob linke Bloecke ausgeblendet werden sollen
 */
function theme_hideleftblocks()
{
    global $themesetting;

    switch (true) {
        case (isset($themesetting['hide-left']) && in_array(1, $themesetting['hide-left'])):
        case theme_hidesideblocks():
            return true;
    }

    $blocks = mxGetAllBlocks('l');
    if (!$blocks) {
        // f�r n�chsten Aufruf vereinfachen
        $themesetting['hide-left'][] = 1;
        return true;
    }
    return false;
}

/**
 * pruefen ob linke Bloecke ausgeblendet werden sollen
 */
function theme_hiderightblocks()
{
    global $themesetting;

    switch (true) {
        case empty($GLOBALS['index']):
        case theme_hidesideblocks():
            return true;
    }

    $blocks = mxGetAllBlocks('r');
    if (!$blocks) {
        // f�r n�chsten Aufruf vereinfachen
        $GLOBALS['index'] = false;
        return true;
    }
    return false;
}

/**
 * pruefen ob linke Bloecke ausgeblendet werden sollen
 */
function theme_hidesideblocks()
{
    global $themesetting;
    return (isset($themesetting['hide-both']) && in_array(1, $themesetting['hide-both']));
}

/**
 * in $newheader ist der gesamte angepasste header enthalten
 */
function theme_header($newheader, &$siteservice, &$debugservice)
{
    global $theme_template, $themesetting;
    /* das Theme verwendet eigene Servicebereiche, deswegen hier die beiden Variablen killen */
    $siteservice = null;
    $debugservice = null;

    /* Layout im body-Tag definieren */
    $class = theme_get_layout_class();
    $theme_template['body_tag'] = preg_replace('#(class\s*=\s*["\'])(.*)(["\'])#', '$1' . trim($class) . '$3', $theme_template['body_tag']);

    /* den body-Tag hinter head-Ende setzen >> nicht veraendern !! */
    $newheader .= "\n</head>\n\n" . $theme_template['body_tag'] . "\n\n";
    // ersetzen von eigenen Theme-Elementen, kann veraendert und ergaenzt werden
    // diese Teile werden vor der Ausgabe des headers im Headbereich ersetzt
    $newheader = theme_replace_header($newheader);

    /* Layout-Typ: fluid oder fixed */
    switch ($themesetting['layouttype']) {
        case 'fluid':
            pmxHeader::add_style(MX_THEME_DIR . '/style/layout.fluid.css.php');
            break;
        default:
            pmxHeader::add_style(MX_THEME_DIR . '/style/layout.fixed.css.php');
    }

    /* Farbschema:  */
    switch (true) {
        case file_exists(dirname(__FILE__) . DS . 'style' . DS . 'color-' . $themesetting['colorscheme'] . '.css');
            pmxHeader::add_style(MX_THEME_DIR . '/style/color-' . $themesetting['colorscheme'] . '.css');
            break;
        default:
            pmxHeader::add_style(MX_THEME_DIR . '/style/color-green.css');
    }

    /* Fixes f�r den IE */
    $browser = load_class('Browser');
    if ($browser->msie) {
        pmxHeader::add_style(MX_THEME_DIR . '/style/ie6.css', 'all', 'lte IE 6');
        pmxHeader::add_style(MX_THEME_DIR . '/style/ie7.css', 'all', 'lte IE 7');
    }

    pmxHeader::add_jquery('jquery.cookie.js');
    pmxHeader::add_script(MX_THEME_DIR . '/js/jquery.mystique.js');

    return $newheader;
}

/**
 * parsen der Seiten-Bloecke
 */
function themesidebox($title, $content, $block = array(), $noecho = 0)
{
    global $theme_template, $themesetting;
    switch (true) {
        case empty($block):
        case empty($block['position']):
        case $block['position'] === 'l':
            $out = $theme_template['block_left'];
            break;
        case $block['position'] === 'r':
            $out = $theme_template['block_right'];
            break;
    }
    $out = str_replace('{BLOCK_CONTENT}' , $content , $out);
    $out = str_replace('{BLOCK_TITLE}' , $title , $out);
    if ($noecho) {
        return $out;
    } else {
        echo $out;
    }
}

/**
 * parsen der Center-Bloecke
 */
function thememiddlebox($title, $content, $block = array(), $noecho = 0)
{
    global $theme_template, $themesetting;

    $out = '';
    switch (true) {
        case empty($block):
        case empty($block['position']):
        case $block['position'] === 'c':
            $block['position'] = 'c';
            $out = $theme_template['block_center_top'];
            break;
        case $block['position'] === 'd':
            $out = $theme_template['block_center_down'];
            break;
    }

    $out = str_replace('{BLOCK_CONTENT}' , $content , $out);
    $out = str_replace('{BLOCK_TITLE}' , $title , $out);
    if ($noecho) {
        return $out;
    } else {
        echo $out;
    }
}

/**
 * News Modul Artikelliste (index.php)
 * $x bedeutet: nicht verwendet, nur zur nuke-Modulkompatibilitaet
 */
function themeindex($x, $x, $x, $x, $x, $x, $x, $x, $x, $x, $x, $x, $story = array())
{
    global $theme_template;
    // nur eine Spalte zulassen :-)
    $GLOBALS['storyhome_cols'] = 1;

    $story = theme_get_story($story);
    if (!empty($story['allmorelink']['bodycount'])) {
        $title = ($story['allmorelink']['bodycount']) ? ' title="' . $story['allmorelink']['bodycount'] . ' ' . _BYTESMORE . '"' : '';
        $story['readmore'] = '<a href="modules.php?name=News&amp;file=article&amp;sid=' . $story['sid'] . '" class="post-readmore"' . $title . '>' . _HREADMORE . '</a>';
    } else {
        $title = '';
    }

    $story['title'] = '<a href="modules.php?name=News&amp;file=article&amp;sid=' . $story['sid'] . '" rel="bookmark"' . $title . '>' . strip_tags($story['title']) . '</a>';

    $story['notes'] = '';
    // die oben definierten Variablen in dem passenden templateteil ersetzen
    $artvars = theme_define_content();
    $out = theme_replace_vars($theme_template[$artvars['themeindex']], $story);

    echo $out;
    return;
}

/**
 * News Modul Artikelansicht (article.php)
 * $x bedeutet: nicht verwendet, nur zur nuke-Modulkompatibilitaet
 */
function themearticle($x, $x, $x, $x, $x, $x, $x, $x, $x, $story = array())
{
    global $theme_template;

    $story = theme_get_story($story);

    $story['title'] = strip_tags($story['title']);
    $story['content'] .= "<br />\n" . $story['bodytext'];
    $story['notes'] = (empty($story['notes'])) ? '' : '<dl class="post-notes"><dt>' . _NOTE . '</dt><dd>' . $story['notes'] . '</dd></dl>';
    // die oben definierten Variablen in dem passenden templateteil ersetzen
    echo theme_replace_vars($theme_template['themeindex'], $story);
    return;
}

/**
 * theme_get_story()
 *
 * @param mixed $story
 * @return
 */
function theme_get_story($story)
{
    $story['comments'] = '';
    $story['readmore'] = '';
    $story['content'] = $story['hometext'];

    $story['title'] = strip_tags($story['title']);

    if (is_file($GLOBALS['tipath'] . $story['topicimage'])) {
        $story['topicimage'] = $GLOBALS['tipath'] . $story['topicimage'];
    } else {
        $story['topicimage'] = $GLOBALS['tipath'] . 'AllTopics.gif';
    }
    $story['topictitle'] = _TOPIC . ': ' . $story['topictext'];

    $dat = strtotime($story['time']);
    $story['posted_month'] = strftime('%b', $dat);
    $story['posted_day'] = date('d', $dat);

    $authorinfo = (empty($story['informant']) || $story['informant'] == $GLOBALS['anonymous']) ? theme_adminname($story) : " " . $story['allmorelink']['informantlink'] . $story['informant'] . "</a>";
    $story['infoline1'] = _NEWSSUBMITED . " " . $authorinfo;

    $story['infoline2'] = '<a href="modules.php?name=News&amp;file=article&amp;sid=' . $story['sid'] . '#comments" class="comments">' . $story['allmorelink']['comments'] . '</a>';

    $tags = array('modules.php?name=Stories_Archive&amp;year=' . date('Y', $dat) => date('Y', $dat),
        'modules.php?name=News&amp;topic=' . $story['topic'] => $story['topictext'],
        'modules.php?name=News&amp;file=categories&amp;catid=' . $story['catid'] => $story['cattitle'],
        );

    $story['tags'] = ' ' . _THEME_TAGS . ': ';
    foreach ($tags as $key => $value) {
        if ($value) {
            $story['tags'] .= '<a href="' . $key . '">' . $value . '</a> ';
        }
    }
    return $story;
}

/**
 * theme_get_mxmenu()
 * CSS-Men� aus dem Men�manager auslesen
 *
 * @return string
 */
function theme_get_mxmenu()
{
    global $themesetting;

    /* Wenn kein Men� angegeben, einfach weg hier... */
    if (empty($themesetting['head_css_menu'])) {
        /* aber auch die twitter und rss Lins ausblenden, weil das sonst doof aussieht */
        pmxHeader::add_style_code('#header .shadow-right.clearfix{padding-bottom:0;}#header p.nav-extra {display:none;}');
        return;
    }

    load_class('Menu', false);

    $menu = pmxMenu::get_menu_instance($themesetting['head_css_menu']);
    $menu->template_path = MX_THEME_DIR;
    $menu->template = 'theme.menu.tpl.html';
    $menu->class_current = 'active';
    $menu->class_additional = 'fadethis';
    if (MX_IS_ADMIN && !$menu->get_tree()) {
        return '<div class="warning">' . sprintf(_THEME_MENU_NOT_EXIST, $themesetting['head_css_menu']) . ' [<a href="admin.php?op=menu">' . _MX_MENU_ADDMENU_EDIT . '</a>]</div>';
    }

    $content = $menu->fetch();
    $menu = null;

    return $content;
}

/**
 * theme_help()
 * Hilfeseite auslesen
 *
 * @return
 */
function theme_help()
{
    $content = file_get_contents(dirname(__FILE__) . DS . 'theme.settings.html');

    $part[] = array('"images/', '"' . MX_THEME_DIR . '/images/'); // normale images im theme
    $part[] = array('url(images/', 'url(' . MX_THEME_DIR . '/images/'); // Hintergrundbilder im theme
    $content = theme_replace_parts($content, $part);

    $styles = theme_extract_optional_part($content, 'Styles');
    $content = theme_extract_optional_part($content, 'Content');

    if ($content) {
        if ($styles) {
            pmxHeader::add_style_code($styles);
        }
        return $content;
    }
    return false;
}

/**
 * theme_preview_settings()
 * Theme-Einstellungen �ber Demo-Block steuern
 * (reserviert f�r pragmaMx Entwicklerteam)
 *
 * @param mixed $themesetting
 * @return
 */
function theme_preview_settings(&$themesetting)
{
    if ($file = realpath(_THISTHEME_ . '/theme.vars.ini')) {
        $requestname = 'thset_' . basename(_THISTHEME_);
        if (isset($_POST[$requestname])) {
            $newvals = $_POST[$requestname];
        } else {
            $newvals = mxSessionGetVar($requestname);
        }
        if ($newvals && is_array($newvals)) {
            $setting = parse_ini_file($file, true);
            $session = array();
            foreach ($newvals as $key => $value) {
                if (isset($setting[$key]) && in_array($value, $setting[$key])) {
                    $themesetting[$key] = $value;
                    $session[$key] = $value;
                }
            }
            mxSessionSetVar($requestname, $session);
        }
    }
}

?>