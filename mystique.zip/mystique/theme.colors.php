<?php
/**
 * pragmaMx - Web Content Management System.
 * Copyright by pragmaMx Developer Team - http://www.pragmamx.org
 *
 * $Revision: 1.2 $
 * $Author: tora60 $
 * $Date: 2011-07-13 21:53:45 $
 */

/* diese Zeile nicht aendern!! */
defined('mxMainFileLoaded') or die('access denied');

/**
 * Standardfarben die im System und den Modulen verwendet werden
 * ACHTUNG!! Diese Farben werden durch die colors.php, des jeweiligen Designs ueberschrieben
 */

global $bgcolor1;
$bgcolor1 = "#fefefe";
global $bgcolor2;
$bgcolor2 = "#efefef";
global $bgcolor3;
$bgcolor3 = "#f3f3f3";
global $bgcolor4;
$bgcolor4 = "#e3e3e3";
global $textcolor1;
$textcolor1 = "#333333";
global $textcolor2;
$textcolor2 = "#75695E";

?>
