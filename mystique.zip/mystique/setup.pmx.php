<?php // $Id: setup.pmx.php,v 1.4 2012-02-25 14:33:43 tora60 Exp $
$credits = '
Mystique v2.0

design by digitalnature, http://digitalnature.eu/
ported by Andi, http://www.pragmamx.org
';

?>