<?php
/**
 * pragmaMx - Web Content Management System.
 * Copyright by pragmaMx Developer Team - http://www.pragmamx.org
 *
 * $Revision: 1.4 $
 * $Author: tora60 $
 * $Date: 2012-02-13 15:05:19 $
 */

define("_THEME_SEARCH", "Ara"); // max. 3 Zeichen
define("_THEME_TAGS", "Tags");
define("_THEME_GOTOP", "top");
define("_THEME_SKIP_LINKS", "H�zl� linkler");
define("_THEME_SKIP_NAVIGATION", "Sayfa navigasyonuna git");
define("_THEME_SKIP_CONTENT", "Sayfan�n i�erik b�l�m�ne git");
define("_THEME_SKIP_SEARCH", "Aramaya git");
define("_THEME_IN", "i�inde:");
define("_THEME_YOUAREHERE", "Buradas�n�z: ");
define("_THEME_LOGIN", "giri�");
define("_THEME_LOGINNICK", "Nik");
define("_THEME_LOGINPASS", "�ifre");
define("_THEME_MENU_NOT_EXIST", "'%s' men�s� not exist.");
define("_THEME_HELLO", "Merhaba");
define("_THEME_MSGPM", "Sizin <a href=\"%s\" title=\"�zel Mesajlar\"><strong>%d</strong> �zel mesaj�n�z var</a>");
define("_THEME_MSGUG", "Sizin <a href=\"%s\" title=\"ki�isel Ziyaret�i Defteri\">ziyaret�i defterinizde <strong>%d</strong> yeni kay�t�n�z bulunuyor</a>");
define("_THEME_ACCOUNT", "�ye hesab�n�z");
define("_THEME_LOGOUT", "��k��");
define("_THEME_USERONLINE", "Kullan�c� �evrimi�i");
define("_THEME_CONTACT_US", "Bizimle ileti�im kurun");
define("_THEME_GOTOHOME", "Ana Sayfa");
define("_THEME_DESIGN", "Renk de&#287;i&#351;tir");
define("_THEME_DEBUGMODEISON", "Hata ay�klama mod�s� aktifle�tirildi!");
define("_THEME_FALSEDOCTYPE", "Bu tema DOCTYPE ayar� olarak XHTML gerektiriyor!");
define("_THEME_RSS", "RSS Feeds");
define("_THEME_TWITTER", "Follow me on Twitter");
define("_THEME_HELP", "? Yardim");
define("_THEME_HELP_DESCRIBE", "Tema yapilandirma men�s� i�in Yardim");

?>