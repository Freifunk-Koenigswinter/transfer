<?php
/**
 * pragmaMx - Web Content Management System.
 * Copyright by pragmaMx Developer Team - http://www.pragmamx.org
 *
 * $Revision: 1.3 $
 * $Author: tora60 $
 * $Date: 2012-02-13 15:05:19 $
 */

define("_THEME_SEARCH", "Go"); // max. 3 letters
define("_THEME_TAGS", "Tags");
define("_THEME_GOTOP", "top");
define("_THEME_SKIP_LINKS", "Quick links");
define("_THEME_SKIP_NAVIGATION", "Springe zur Seitennavigation");
define("_THEME_SKIP_CONTENT", "Springe zum Inhaltsbereich der Seite");
define("_THEME_SKIP_SEARCH", "Springe zur Suche");
define("_THEME_IN", "in");
define("_THEME_YOUAREHERE", "Du befindest dich hier: ");
define("_THEME_LOGIN", "login");
define("_THEME_LOGINNICK", "Nickname");
define("_THEME_LOGINPASS", "Passwort");
define("_THEME_MENU_NOT_EXIST", "Das Men� '%s' existiert nicht.");
define("_THEME_HELLO", "Hallo");
define("_THEME_MSGPM", "Du hast <a href=\"%s\" title=\"private Nachrichten\"><strong>%d</strong> Nachrichten</a>");
define("_THEME_MSGUG", "Du hast <a href=\"%s\" title=\"Benutzerg�stebuch\"><strong>%d</strong> neue G�stebucheintr�ge</a>");
define("_THEME_ACCOUNT", "Dein Account");
define("_THEME_LOGOUT", "ausloggen");
define("_THEME_USERONLINE", "User online");
define("_THEME_CONTACT_US", "Kontaktiere uns");
define("_THEME_GOTOHOME", "zur Startseite");
define("_THEME_DESIGN", "Farbe ausw�hlen");
define("_THEME_DEBUGMODEISON", "Debug-Modus ist eingeschaltet!");
define("_THEME_FALSEDOCTYPE", "Dieses Theme erfordert XHTML als DOCTYPE Einstellung!");
define("_THEME_RSS", "RSS Feeds");
define("_THEME_TWITTER", "Follow me on Twitter");
define("_THEME_HELP", "? Hilfe");
define("_THEME_HELP_DESCRIBE", "Hilfe zur Theme-Konfiguration aufrufen");

?>