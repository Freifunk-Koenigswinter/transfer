<?php
/**
 * pragmaMx - Web Content Management System.
 * Copyright by pragmaMx Developer Team - http://www.pragmamx.org
 *
 * $Revision: 1.5 $
 * $Author: tora60 $
 * $Date: 2012-02-13 15:05:19 $
 */

define("_THEME_SEARCH", "Go"); // max. 3 letters
define("_THEME_TAGS", "Tags");
define("_THEME_GOTOP", "Haut");
define("_THEME_SKIP_LINKS", "Liens rapides");
define("_THEME_SKIP_NAVIGATION", "Vers la navigation");
define("_THEME_SKIP_CONTENT", "Vers le contenu");
define("_THEME_SKIP_SEARCH", "Vers la recherche");
define("_THEME_IN", "Dans");
define("_THEME_YOUAREHERE", "Vous &ecirc;tes ici: ");
define("_THEME_LOGIN", "Connexion");
define("_THEME_LOGINNICK", "Pseudo");
define("_THEME_LOGINPASS", "Pass");
define("_THEME_MENU_NOT_EXIST", "Le menu '%s' n'�xiste pas.");
define("_THEME_HELLO", "Bonjour");
define("_THEME_MSGPM", "Vous avez <a href=\"%s\" title=\"private messages\"><strong>%d</strong> message(s)</a>");
define("_THEME_MSGUG", "Vous avez <a href=\"%s\" title=\"User guestbook\"><strong>%d</strong> entr�e(s) dans votre livre d\'or</a>");
define("_THEME_ACCOUNT", "Votre compte");
define("_THEME_LOGOUT", "D�connexion");
define("_THEME_USERONLINE", "Utilisateur(s) en ligne");
define("_THEME_CONTACT_US", "contactez-nous...");
define("_THEME_GOTOHOME", "vers la page d\'accueil");
define("_THEME_DESIGN", "Choix de la couleur");
define("_THEME_DEBUGMODEISON", "Mode-Debug activ� !");
define("_THEME_FALSEDOCTYPE", "Ce th�me n�cessite un DOCTYPE XHTML !");
define("_THEME_RSS", "RSS Feeds");
define("_THEME_TWITTER", "Suivez moi sur Twitter");
define("_THEME_HELP", "? Aider");
define("_THEME_HELP_DESCRIBE", "Aide pour le menu de configuration du th�me");

?>
