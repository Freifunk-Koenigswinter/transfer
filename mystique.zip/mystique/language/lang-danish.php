<?php
/**
 * pragmaMx - Web Content Management System.
 * Copyright by pragmaMx Developer Team - http://www.pragmamx.org
 *
 * $Revision: 1.4 $
 * $Author: tora60 $
 * $Date: 2012-02-02 07:24:09 $
 */

include(dirname(__FILE__) . '/lang-german.php');

?>