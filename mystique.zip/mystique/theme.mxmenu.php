<?php
/**
 * pragmaMx - Web Content Management System.
 * Copyright by pragmaMx Developer Team - http://www.pragmamx.org
 *
 * pragmaMx is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * $Revision: 1.1 $
 * $Author: tora60 $
 * $Date: 2011-05-03 08:14:25 $
 */

defined('mxMainFileLoaded') or die('access denied');

class Theme_Mx_Menu extends pmxMenu {
    /* Konstruktor ;) */
    function __construct()
    {
        /* normale Klappfunktion abschalten */
        $this->normal_events = false;
        // $this->stylesheet = MX_THEME_DIR . '/style/mx-menu.css';
        $this->template_path = MX_THEME_DIR;
        $this->template = 'theme.mxmenu.tpl.html';
        $this->class_additional = 'fadethis';

        /* in der normalen Klasse weiter... */
        return parent::__construct();
    }

    /**
     * pmxMenu::fetch()
     *
     * @return
     */
    public function fetch()
    {
        $menu = $this->_level();

        if (!$this->_menu_tree) {
            return $menu;
        }

        /* ist menue aufklappbar? nur, wenn auch Submenues vorhanden sind */
        $topcount = count($this->_menu_tree[0]['sub']);
        $allcount = count($this->_menu_tree)-1; // [0] abziehen
        $expandable = ($allcount > $topcount);

        if ($expandable) {
            /* Javascript fur Klappfunktion in Headbereich integrieren */
            pmxHeader::add_jquery('ui/jquery-ui-pmx-core.min.js', 'ui/jquery.ui.accordion.min.js', 'ui/jquery.effects.core.min.js');
        }

        /* Stylesheet in Headbereich integrieren */
        pmxHeader::add_style($this->stylesheet);

        return $menu;
    }
}

?>
